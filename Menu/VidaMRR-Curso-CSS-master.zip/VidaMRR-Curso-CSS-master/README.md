Curso CSS
=================

Bienvenido al curso de CSS de Vida MRR.
En este espacio encontrarás los archivos necesarios para poder realizar los videos del curso. Es indispensable descargarlos ya que de otra forma no se podrá seguir el aprendizaje de acuerdo al temario del curso.

Conforme se vayan necesitando más archivos se irá actualizando el repositorio.

=================
Vida MRR © 2015 Derechos Reservados
